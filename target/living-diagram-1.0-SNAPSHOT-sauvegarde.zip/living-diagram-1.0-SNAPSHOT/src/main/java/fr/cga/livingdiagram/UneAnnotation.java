package fr.cga.livingdiagram;

public class UneAnnotation {

    public final String nom;

    public UneAnnotation(String nom) {
        this.nom = nom;
    }
}
