package fr.cga.livingdoc.qdox;

public class UnParametre {

    public final String nom;
    public final String type;

    public UnParametre(String nom, String type) {
        this.nom = nom;
        this.type = type;
    }
}