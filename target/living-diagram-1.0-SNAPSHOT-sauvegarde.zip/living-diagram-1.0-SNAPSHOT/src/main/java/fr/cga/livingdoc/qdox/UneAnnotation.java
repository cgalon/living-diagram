package fr.cga.livingdoc.qdox;

public class UneAnnotation {

    public final String nom;

    public UneAnnotation(String nom) {
        this.nom = nom;
    }
}
