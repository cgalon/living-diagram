package fr.pe.incub.mescomics.referentiel.domaine;

public class Episode{

}
