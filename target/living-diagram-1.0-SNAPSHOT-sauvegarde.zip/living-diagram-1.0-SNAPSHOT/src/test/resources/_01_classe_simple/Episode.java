package fr.pe.incub.mescomics.referentiel.domaine;

/**
 * Morceau d'histoire d'un héros paru dans un numéro d'une revue.
 */
public class Episode{

}
